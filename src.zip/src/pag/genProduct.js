import React from 'react'
import Produnit from './produnit'
export default function genProduct({personajes}) {


  return (
<section className='product_container'>
  {
    personajes.map((personaje) => (
      <Produnit key={personaje.id} personaje={personaje}/> 
  ))}

</section>
  )
}