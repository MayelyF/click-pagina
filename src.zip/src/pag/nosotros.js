import React, { Component } from 'react'

export default class Nosotros extends Component {
  render() {
    return (
    <div>

        <div className="container p-5">
        <div className="row">
            <div className="cropped col">
            <img src="/img/Diseño sin título (2).png"/>
            </div>
            <div className="col">
            <h3>Nosotros</h3><br/>
            <h8>Laboratorios a Domicilio</h8><br/><br/>
            <p className="paragraph">En ClickLab contamos con el equipo científico y técnico de alto rendimiento y equipos de alta gama, adicional contamos con profesionales que se capacitan continuamente para brindar el mejor servicio.
    ​          Nos preocupamos por la tranquilidad de nuestros pacientes y clientes, para tener un servicio único, pero sobre todo profesional y a un precio justo.
    ​          No sólo puedes visitarnos en nuestras instalaciones, nosotros vamos a tu domicilio sin costo adicional. 
    ​          En ClickLab, con tan solo un click estamos en tu domicilio.</p>
            </div>
        </div>
        </div>

    </div>

    )}
}
