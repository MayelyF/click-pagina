import React, { Component } from 'react'
import Prod2 from './scr/prod2'


export default class Principal extends Component {
  render() {


    return (
      <div>

        <div className='centrar'>
          <form onSubmit={console.log("aaswdfg")}>
            <input type='text' placeholder='Buscar...'className='inpabcd'/>
            <button type='submit'className='btabcd'>buscar</button>
          </form>
        </div>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <div id="carouselExampleIndicators" className="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
          </ol>

          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="/img/1.png" alt="First slide"/>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="/img/2.png" alt="Second slide"/>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="/img/7.png" alt="Third slide"/>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="/img/4.png" alt="Four slide"/>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="/img/Festeja a Papá Check UP MASCULINO (4).png" alt="Fifth slide"/>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="/img/5.png" alt="Fifth slide"/>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="/img/6.png" alt="Fifth slide"/>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="/img/carr.png" alt="Fifth slide"/>
            </div>
          </div>

          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>

        <div className="Faltante1">
          <div className='contimg2'><img src='./img/productos/PCRINF.webp' className='imgProd2'></img></div>
          <div className='contimg2'><img src='./img/productos/PCRINF.webp' className='imgProd2'></img></div>
          <div className='contimg2'><img src='./img/productos/PCRINF.webp' className='imgProd2'></img></div>
        </div>

            <div class="product_container">

              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PROMCOV.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>
              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PROMCOV.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>

              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PCRDOMICILIO.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>
            </div>

        <div id='producto'>

        <div class="product_container">
              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PRUEANT.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>

              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/CUPTCOV.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>

              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PASARS.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>
            </div>

            <div class="product_container">
              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PCRINF.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>

              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PROMCOV.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>

              <div class="productcontainer2">
              <div class="producto">
                <div class=" img_container">
                  <div class="img2"><img src='./img/productos/PCRDOMICILIO.webp' className='imgProd'></img></div>
                  </div>

                  <div class="text-mor">
                    <a href="#" class="text-mor">Prueba antígenos</a>
                  </div>

                  <div class="text-mor">
                    <div class="line">____________</div>          
                    15 min <br/>
                    $1,399
                    </div>
                    <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
                </div>
              </div>
            </div>


        </div>


  <div class=" img_container">
    <div class="img3"><img src='img/im1.jpg' className='prod2img'/> </div>
    <div class="img3"><img src='img/im2.jpg' className='prod2img'/></div>
    <div class="img3"><img src='img/im3.jpg' className='prod2img'/></div>
</div>


<div class="contacto">
    <h2>Clientes</h2>
    <div class="text-mor">Trabajando juntos</div>
</div>

<div class="contact_container">
    <div class="contact_panel">
        <img src="/img/falt.jpg" alt="" class="img-contact"/>
        <div class="text-mor2">Evento Ikal campamento</div>
    </div>
    
    <div class="contact_panel">
        <img src="/img/falt.jpg" alt="" class="img-contact"/>
        <div class="text-mor2">Socio Comercial</div>
    </div>
    
    <div class="contact_panel">
        <img src="/img/falt.jpg" alt="" class="img-contact"/>
        <div class="text-mor2">Pruebas Empresariales</div>
    </div>
    
    <div class="contact_panel">
        <img src="/img/falt.jpg" alt="" class="img-contact"/>
        <div class="text-mor2">Sector Turistico</div>
    </div>
</div>


      <div className='BG2'>
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="caritcont">
                <div class="imgfalt"></div>
                <div class="txt-gr">
                  Nosotros contratamos el servicio para viajar a Estados Unidos,
                  nos entregaron el certificado y no tuvimos ningún problema en el
                  aeropuerto, excelente servicio recomendado.
                  <br/>
                  <div class="text-mor">Familia Téllez</div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="caritcont">
                <div class="imgfalt"></div>
                <div class="txt-gr">
                  Quise dar seguimiento a mi salud después de haber tenido COVID. 
                  El servicio es espectacular, me hice un Check Up Post Covid y fueron
                  a mi domicilio y el personal está altamente calificado, muy serviciales
                    y con todos los protocolos de seguridad.
                  <br/>
                  <div class="text-mor">Yadhira Zuñiga</div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="caritcont">
                <div class="imgfalt"></div>
                <div class="txt-gr">   
                  Me realice una prueba de anticuerpos a domicilio, el servicio me lo 
                  recomendó mi primo y todo estuvo muy bien, volveria a contratar sus servicios.
                  <br/>
                  <div class="text-mor">Carlos Mejía</div>
                </div>
              </div>
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>

  <div class="contacto">
    <div>
        <h2>Contacto</h2>
    </div>
    <div>
        <div class="text-mor">Gracias por su interés en nuestros servicios. Póngase en contacto con nosotros(as) si tiene alguna pregunta o comentario.</div>
        <div class="text-mor">Bajio 234 Col. Roma Sur Alcaldía Cuauhtémoc CdMx</div>
        <div class="text-mor">hola@clicklab.mx</div>
        <div class="text-mor">55 8941 0004</div>
    </div>
</div>

<div >
    <form>
      <div class="message">
        <div class="text-mess5">Nombre</div>
        <input type="text" placeholder="Ingresa tu nombre" class="input-mess"/><br/>

        <div class="text-mess5">E-mail</div>
        <input type="text" placeholder="Ingresa tu email" class="input-mess"/><br/>

        <div class="text-mess5">Asunto</div>
        <input type="text" placeholder="Escribe el asunto" class="input-mess"/><br/>
        
        <div class="text-mess5">Mensaje</div>
        <input type="text" placeholder="Escribe tu mensaje aquí..." class="input-mess"/><br/>
      </div> 

      <div className="centrar">
        <button class="sub-button">Enviar</button>
      </div> 

    </form>
</div> 


    <div class="reservacion">
    <div class="text-mor">Agenda tu reservación</div>
    <div class="strReserva">
        Fecha <br/>
        <input type="date" class="input-sub2" placeholder="Fecha"/>
    </div>

    <div class="strReserva">
        Hora <br/>
        <input type="time" name="" id="" class="input-sub2" placeholder="Hora"/>
    </div>
    <div class="strReserva">
        Cantidad de personas <br/>
        <input type="numer" min="1" max="30" class="input-sub2" placeholder="Cantidad de personas"/>
        <btn/>
    </div>
      <btn/>
    <button class="btn_add_cart">enviar</button>
</div>
<div class="container p-5">
    <div class="row">
      <div class="col text-center">
      <form>
        <h4>Formulario de suscripción</h4>
        <input type="text" placeholder="Dirección de email" class="input-sub"/><br/>
        <button class="sub-button">Enviar</button>
      </form>
    </div>
    </div>
  </div>
<div>
  <div className='reserva'></div>
</div>


      </div>
      
    )
  }

  
}
