import React, { Component, useState } from 'react'
import ItemCart from './itemCart'

export default function useCart (){

    const [ahorro, setahorro] = useState(0)
    const [total, settotal] = useState(0)
    const array = [50,37,25,44]





    return (
      <div>

          {
            array.map((user)=>(
              <ItemCart user={user} key={user} />
            ))
          }

        <div className='botonFin'>
          <div>Total a pagar: {total} </div>
          <div>Ahorro: {ahorro} </div>
          <button >Comprar</button>
        </div>
      </div>
    )

}
