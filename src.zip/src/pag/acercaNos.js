import React, { Component } from 'react'

export default class acercaNos extends Component {
  render() {
    return (
      <div>
 <div className='BG2'>
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="caritcont">
                <div class="txt-gr">   
                    <h2>Angela</h2>
                    <br/>
                    <div class="text-mor">Director de operaciones</div>
                    </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                    <h2>Rodrigo</h2>
                    <br/>
                    <div class="text-mor">Director general</div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Marisela</h2>
                  <br/>
                  <div class="text-mor">Director de administracion</div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Karla</h2>
                  <br/>
                  <div class="text-mor">Responsable quimico</div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Karla</h2>
                  <br/>
                  <div class="text-mor">Gerente administrativo</div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Jayro</h2>
                  <br/>
                  <div class="text-mor">Gerente comercial</div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Shai</h2>
                  <br/>
                  <div class="text-mor">Supervisor comercial</div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Ana Laura</h2>
                  <br/>
                  <div class="text-mor">Ejecutivo atencion a clientes</div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Mariana</h2>
                  <br/>
                  <div class="text-mor">Jefa de enfermeras </div>
                </div>
              </div>
            </div>


            <div class="carousel-item">
              <div class="caritcont">
                <div class="txt-gr">   
                  <h2>Equipo Técnico, Enfermeras, Choferes, Químicos, Servicio y más...</h2>
                  <br/>
                    <div class="text-mor5">Gracias a todos nuestros colaboradores que con su amor y 
                    empeño hacen posible la operación de Lunes a Domingo para nuestros Pacientes y 
                    amigos.
                    </div>
                </div>
              </div>
            </div>


          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>

      </div>
    )
  }
}
