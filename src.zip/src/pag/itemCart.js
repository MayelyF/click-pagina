import axios from 'axios';
import React, { useState } from 'react'


export default function ItemCart({user}) {
    const [Producto, setProducto] = useState({})

    window.onload= myfunction;
    function myfunction(){
        axios.post(  'http://localhost:3001/register5', {UserName:user})
        .then(res => {
            console.log(res.data)
            setProducto(res.data)
            console.log(res.data.Metodologia)
      
        }).catch(error=>{
            alert('Error al actualizar')
            console.log(error);
        })
    }

  return (
    <div>
        <div className='productCart'>
            <div className='cartpr1' ></div>
            <div className='cartpr2' >
                <div className='cartpr3' >{Producto.NombreServicio}</div>
                <div className='cartpr3' >
                <div className='cartpr4' >Tipo de muestra:<br/>{Producto.TipoMuestra} </div>
                <div className='cartpr4' >Tipo de metodologia:<br/>{Producto.Metodologia}</div>
                <div className='cartpr4' >Precio:<br/>{Producto.PrecioLista} </div>
                </div>
            </div>
        </div>

    </div>
  )
}
