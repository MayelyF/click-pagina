import React, { Component } from 'react'

export default class Vacantes extends Component {
  render() {
    return (
      <div>

<div className="container p-5">
    <div className="row">
        <div className="col-lg-12 text-center">
        <h2>Vacantes</h2>
        <h5>Oportunidades en ClickLab</h5>
    </div>
    </div>
    <div className="row">
        <div className="col-sm-2">
            <p className="paragraph">1 de junio 2021</p>
            <p className="light-paragraph">Gerente Comercial zona Centro</p>
        </div>
        <div className="col-dm-6">
            <p className="paragraph">Buscamos Gerente Comercial para zona centro y bajío de la República Mexicana.</p>
            <p className="paragraph">Experiencia mínima de 5 años en puestos similares en ventas y de preferencia como representante médico.</p>
        </div>
    </div>
    <div className="row">
        <div className="col-sm-2">
            <p className="paragraph">11 de Junio 2021</p>
            <p className="light-paragraph">Atencion a Clientes</p>
        </div>
        <div className="col-dm-6">
            <p className="paragraph">Buscamos personal para el área de Atención a Clientes, con experiencia y gusto por el trato con el cliente y ventas.</p>
        </div>
    </div>
    <div className="row">
        <div className="col-sm-2">
            <p className="paragraph">11 de Junio 2021</p>
            <p className="light-paragraph">Tomador de Muestra</p>
        </div>
        <div className="col-dm-6"><p className="paragraph">Buscamos enfermeras para toma de muestras-.</p>
        </div>
    </div>
</div>

      </div>
    )
  }
}
