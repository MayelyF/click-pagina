const db = require('./dbData');
const express = require('express')
const cors = require('cors')
const sql = require('mssql')
const bodyParser = require('body-parser')
const app = express()
app.use(cors())
app.use(express.json());
/*app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json({ limit: '10mb' }))*/
// const JWT = require('jsonwebtoken')
// const secretWord = 'Samus#Aran'


const config = {
    user: db.user,
    password: db.password,
    server: db.server, 
    database: db.database,
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: false, // for azure
        trustServerCertificate: false // change to true for local dev / self-signed certs
    }
};
app.get('/', (req, res) => {
	res.send('hola desde tu primera ruta de la Api')
})
app.post('/api/login', (req, res) => {

    const UserName = req.body.UserName,
        UserPassword = req.body.UserPassword,
        IdPerfil = req.body.IdPerfil

    async function authenticate() {
        try {
            const pool = await sql.connect(config)
            const result = await pool.request().execute('SPS_Login')
            //query('SELECT * FROM TblUsuarios')
            const resp = result.recordset
            //console.log(resp);
            let i
            let tf = []
            for (i = 0; i < resp.length; i++) {
                if (resp[i].UserName === UserName && resp[i].UserPassword === UserPassword) {
                    
                    console.log("Id perfil: "+resp[i].IdPerfil +" Username: "+resp[i].UserName + " Contraseña: "+ resp[i].UserPassword);
                    if(resp[i].IdPerfil===1){
                        console.log("Es administrador")
                        var redir = { redirect: "/admin" };
                        return res.json(redir);
                        //res.redirect('/admin')
                    }
                    if(resp[i].IdPerfil===2){
                        console.log("Es chofer")
                        var redir = { redirect: "/Profile_chofer" };
                        return res.json(redir);
                        //res.redirect('/admin')
                    }
                    if(resp[i].IdPerfil===4){
                        console.log("Es enfermero")
                        var redir = { redirect: "/Profile_Enfermero" };
                        return res.json(redir);                
                    }
                
                    /* switch(resp[i].IdPerfil){
                        case 1: 
                        app.get('/admin', (req,res)=>{
                            console.log("Es administrador")
                            res.send('<h1>Hola Administrador</h1>')
                            res.redirect(301, '/admin')
                        })
                        break;
                    case 4: 
                        app.get('/Profile_Enfermero', (req,res)=>{
                            res.send('<h1>Hola Supervisor</h1>')
                        })
                        break;
                    }*/
                
                   // tf[i] = true
                    //console.log(resp[i]);
                } else {
                    tf[i] = false
                }

            }

            /*const encontrado = tf.indexOf(true)
            if (encontrado !== -1) {
                console.log('encontrado') //esto se modifica
            for (i = 0; i < resp.length; i++) {          
                switch(resp[i].IdPerfil){
                    case 1: 
                    app.get('/admin', (req,res)=>{
                        console.log("Es administrador")
                        res.send('<h1>Hola Administrador</h1>')
                        res.redirect(301, '/admin')
                    })
                    break;
                case 2: 
                    app.get('/Profile_Enfermero', (req,res)=>{
                        res.send('<h1>Hola Supervisor</h1>')
                    })
                    break;
                }
            }
                //res.redirect(301, '/admin')
                // window.location = "/admin"
            } else {
                console.log('no encontrado'); //esto también
                app.get('/error', (req,res)=>{
                    res.status(404).send('<h1>El usuario no existe en la bd</h1>')
                })
            }*/

        } catch (err) {
            console.error(err);
        }
    }

    authenticate()
})

app.post('/api/registrar', (req, res) => {
    async function registrar(){
        const UserName = req.body.UserName,
            UserPassword = req.body.UserPassword,
            CorreoU = req.body.CorreoU
        try{
                let pool = await sql.connect(config)
                await pool.request().input('UserName', sql.VarChar, `${UserName}`) //cada input es un campo a llenar
            .input('CorreoU', sql.VarChar, `${CorreoU}`)
            .input('UserPassword', sql.VarChar, `${UserPassword}`)
            .query(`INSERT INTO TblUsuarios (UserName, CorreoU, UserPassword) VALUES 
            (@UserName, @CorreoU, @UserPassword)`)
            console.log('User inserted')
            
        } catch(error) {
            console.error(error)
        }
    }

    registrar()
})

/*app.post('/api/login', (req, res) => {
    const {UserName} = req.body;
    const {UserPassword} = req.body;
	const values = [UserName, UserPassword];
    sql.connect(config).then(() => {
        console.log("Connected to database")
  return sql.query`select IdUsuario from TblUsuarios where UserName='${req.body.UserName}' and UserPassword='${req.body.UserPassword}'`;
        
    }).then(result => {
        
        if(result == 5){
            res.status(200).send('login');
        }
    }).catch(err => {
        console.log(err);
        res.send(err);
    })
})*/

       /*  var connection = sql.connect(config)
          connection.query("SELECT * FROM TblUsuarios WHERE UserName = ? AND UserPassword = ?", values, (err, result) => {
              if (err) {
                  res.status(500).send(err)
              } else {
                  if (result.length > 0) {
                      res.status(200).send({
                          "IdUsuario": result[0].IdUsuario,
                          "UserName": result[0].UserName
                      })
                  } else {
                      res.status(400).send('Usuario no existe')
                  }
              }
          })
          connection.end()*/
     

app.listen(4000, () => console.log('hola soy el servidor'))




