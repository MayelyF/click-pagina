import React, { Component } from 'react';
import {
    BrowserRouter as Router,
    Routes,
    Route
  } from "react-router-dom";
  import Principal from './principal'
  import Register from './register'
  import Login from './login'
  import Vacantes from './vacantes'
  import Nosotros from './nosotros'
  import Cobertura from './cobertura'
  import Contacto from './contacto'
  import Pruebas from './pruebas'
  import Cart from './cart'
  import Sucursales from './sucursales'
  import AdmUser from './usersCRM/Admin/AdmUser';
  import Graficas from './usersCRM/Admin/graficas';
  import Enfermeras from './usersCRM/Admin/enfermeras';
  import Choferes from './usersCRM/Admin/choferes';
  import Certificados from './usersCRM/Admin/certificados';
  import Clientes from './usersCRM/Admin/clientes';
  import Nmenudesign from './usersCRM/Admin/nmenudesign';
  import Perfiles from './usersCRM/Admin/perfiles';
  import ProfCreator from './usersCRM/Admin/profCreator';
  import Productos from './usersCRM/Admin/productos';
  import ProdCreator from './usersCRM/Admin/ProdCreator';
  import Chof from './usersCRM/choferes/choferes'
  import AcercaNos from './acercaNos';
  import LogGr from './logwr'
  import Enfermeras2 from './usersCRM/enfermers/enfermeras';
  import Formulario from './usersCRM/enfermers/App '
  import Visualizador from './usersCRM/enfermers/visualizador';
  import GenCert from './usersCRM/enfermers/gencert';
  import CertForm from './certificados/App';
  import Productos2 from './productos';


export default class AppRouter extends Component {
  render() {
    return (
        <div>
            <Router>
                <Routes>
                    <Route path="/" element={<Principal />} />
                    <Route path="/Register" element={<Register />} />
                    <Route path="/Login" element={<Login />} />
                    <Route path="/vacantes" element={<Vacantes />} />
                    <Route path="/nosotros" element={<Nosotros />} />
                    <Route path="/cobertura" element={<Cobertura />} />
                    <Route path="/contacto" element={<Contacto />} />
                    <Route path="/pruebas" element={<Pruebas />} />
                    <Route path="/cart" element={<Cart />} />
                    <Route path="/nuestro_equipo" element={<AcercaNos />} />
                    <Route path="/sucursales" element={<Sucursales />} />
                    <Route path="/admin" element={<AdmUser />} />
                    <Route path="/poreditar1" element={<Graficas />} />
                    <Route path="/poreditar2" element={<Enfermeras />} />
                    <Route path="/poreditar3" element={<Choferes />} />
                    <Route path="/poreditar4" element={<Productos />} />
                    <Route path="/poreditar5" element={<Perfiles />} />
                    <Route path="/poreditar6" element={<Clientes />} />
                    <Route path="/poreditar7" element={<Certificados />} />
                    <Route path="/poreditar8" element={<Nmenudesign />} />
                    <Route path="/NuevoPerfil" element={<ProfCreator />} />
                    <Route path="/NuevoProducto" element={<ProdCreator />} />
                    <Route path="/Profile_chofer" element={<Chof />} />
                    <Route path="/loginr" element={<LogGr />} />
                    <Route path="/Profile_Enfermero/formulario" element={<CertForm />} />
                    <Route path="/Profile_Enfermero" element={<Enfermeras2 />} />
                    <Route path="/doc" element={<Visualizador />} />
                    <Route path="/Profile_Enfermero/GenerarCertificado" element={<GenCert/>} />
                    <Route path="/Tienda" element={<Productos2 />} />
                </Routes>
            </Router>
        </div>
    );
  }
}
