import React, { Component } from 'react'

export default class Cobertura extends Component {
  render() {
    return (
      <div>
          <img src="/img/5_edited_edited_edited_edited.jpg" width="90%"></img>
      </div>
    )
  }
}
