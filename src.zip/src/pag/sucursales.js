import React, { Component } from 'react'

export default class Sucursales extends Component {
  render() {
    return (
      <div>
          <div className='contacto'>
              <h2>sucursales</h2>
              <div className='text-mor'>Presiona la imagen para desplegar su mapa</div>
          </div>

        <div className=" img_container">
           <div className="img3"><img src='img/suc (1).png' className='prod2img'/></div>
           <div className="img3"><img src='img/suc (2).png' className='prod2img'/></div>
        </div>
        <div className=" img_container">
           <div className="img3"><img src='img/suc (3).png' className='prod2img'/></div>
           <div className="img3"><img src='img/suc (4).png' className='prod2img'/></div>
        </div>
        <div className=" img_container">
           <div className="img3"><img src='img/suc (5).png' className='prod2img'/></div>
           <div className="img3"><img src='img/suc (6).png' className='prod2img'/></div>
        </div>
      </div>
    )
  }
}
