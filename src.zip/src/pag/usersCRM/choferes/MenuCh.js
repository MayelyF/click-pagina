import { useState } from 'react'
import React from 'react'

export default function useNmenuCho() {
    const [Sidebar, setSidebar] = useState(false)

    const ShowSidebars = () => setSidebar(!Sidebar)
     return (
          <div>
              <div class={ Sidebar ? 'sidebar active'  : 'sidebar' }>
                  <div className='logsidebar'>
                      <div className='logCont'>
                          <i class='bx bxl-c-plus-plus'></i>
                          <div className='logTxt'>Clicklab</div>
                      </div>
                      <i class='bx bx-menu' id='btn' onClick={ShowSidebars}></i>
                  </div>
                  <ul className='nav_list'>
                      <li>
                          <a href='/Profile_chofer'>
                              <i class='bx bxs-home-alt-2'></i>
                              <span className='links_name'>Horario</span>
                          </a>
                          <span className='tool'>Horario</span>
                      </li>
                  </ul>
                  <div className='profile_content'>
                      <div className='profileSide'>
                          <div className='profile_details'>
                              <img src='/img/profile.jpg' alt='' className='' />
                              <div className='name_job'>
                                  <div className='name'>Daniel</div>
                                  <div className='job'>sdadasa</div>
                              </div>
                          </div>
                          <i class='bx bx-log-in' id='log_out'></i>
                      </div>
                  </div>
              </div>

          </div>
    )
}

