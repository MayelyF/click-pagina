import React, { Component } from 'react'
import NmenuCho from './MenuCh'

export default class choferes extends Component {
  render() {
    return (
      <div className='home_content'>
          <NmenuCho/>
          <div className='content1'>
                <span>Horario</span>
            </div>

            <div className='content'>
                <div className='Nombre'>     
                    <span>Nombre1</span>
                </div>
                <div className='semanas'>Semana 1</div>
                <div className='dashboard2'></div>
            </div>    
      </div>
    )
  }
}
