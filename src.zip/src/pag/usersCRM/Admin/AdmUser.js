import React, { Component } from 'react'
import Nmenu from './nmenudesign'
export default class AdmUser extends Component {
  render() {
    return (
    <div className='home_content'>
      <Nmenu/>


        <div className='dashboard'> 
        </div>
        <div>
          <div className='graphs3'>
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>
        <div>
          <div className='graphs2'>
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>

    </div>
    )
  }
}
