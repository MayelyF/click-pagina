import React, { Component } from 'react'
import Nmenudesign from './nmenudesign'

export default class profCreator extends Component {
  render() {
    return (
      <div className='home_content'>
        <Nmenudesign/>
        <div>
            <div className='content1'>
                <span>Perfil Manager</span>
            </div>

            <div className='content'>
              <div className='dashboard6'>
                <div className='profDB'>
                  Nuevo Perfil
                </div>

                <div className='perfilDB'>
                    <div className='datUse1'>nombre:</div>
                    <div className='datUse1'> <input /> </div>

                    <div className='datUse1'>id perfil:</div>
                    <div className='datUse1'> <input /> </div>

                    <div className='datUse1'>celular</div>
                    <div className='datUse1'> <input /> </div>

                    <div className='datUse1'>E-mail:</div>
                    <div className='datUse1'> <input /> </div>

                    <div className='datUse1'>CP</div>
                    <div className='datUse1'> <input /> </div>

                    <div className='datUse1'>Direccion</div>
                    <div className='datUse1'> <input /> </div>

                </div>


              </div>

            </div>
            
          </div>
      </div>
    )
  }
}
