import React, { Component } from 'react'

export default class Adminview extends Component {
  render() {
    return (
      <div>
                <div className='navar'>
          <div className='navizq'><button className='space'><i class="fa-brands fa-sistrix"></i></button> <input placeholder='buscar'className='buscador'/> </div>
          <div className='navder'>
            <div className='btnnavar'><i class="fa-regular fa-envelope"></i></div>
            <div className='btnnavar'><i class="fa-solid fa-user"></i></div>
          </div>
        </div>
        <div className='menuL'>
          <img src="/img/CLAB LOGO IMAGEN FONDO BLANCO TRANSPARENTE.png" className="log12" alt="Website Logo"/>
          <ul>
            <li><a href="/admin" className='activo1'><i class="fa fa-address-card" aria-hidden="true"></i> Dashboard inicial</a></li>
            <li><a href="/poreditar1" className='activo1'><i class="fa fa-address-card" aria-hidden="true"></i> E.commerce</a></li>
            <li><a href="/poreditar2" className='activo1'><i class="fa fa-address-card" aria-hidden="true"></i> Enfermeros</a></li>
            <li><a href="/poreditar3" className='activo1'><i class="fa fa-address-card" aria-hidden="true"></i> Choferes</a></li>
            <li><a href="/poreditar4" className='activo1'><i class="fa fa-server" aria-hidden="true"></i> ....</a></li>
            <li><a href="/poreditar5" className='activo1'><i class="fa fa-address-card" aria-hidden="true"></i>  Perfiles</a></li>
            <li><a href="/poreditar6" className='activo1'><i class="fa fa-address-card" aria-hidden="true"></i> Clientes</a></li>
            <li><a href="/poreditar7" className='activo1'><i class="fa fa-car" aria-hidden="true"></i> Certificados</a></li>
          </ul>
        </div>

      </div>
    )
  }
}
