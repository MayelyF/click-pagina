import React, { Component } from 'react'
import Nmenudesign from './nmenudesign'

export default class productos extends Component {
  render() {
    return (
      <div className='home_content'>
          <Nmenudesign/>

          <div>
            <div className='content1'>
                <span>Productos</span>
            </div>

            <div className='content'>
              <div className='Nombre'>     
                <form id="formulario" method="POST" >
                  <input name ="user"  type="text" className="input-sub" placeholder="Producto" id="UserLogin" />
                  <button type="submit" className="btbuscador" id="btnLogin">Buscar</button>
                  <ul className="error" id="error" ></ul>
                </form>
              </div>
              <div className='bCon'><a href='/NuevoProducto'>Crear nuevo producto</a></div>
              <div className='dashboard6'>
                <div className='profDB'>Productos</div>

                <div className='productlDB'>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id:</div>
                    <div className='datUse'>Costo</div>
                    <div className='datUse'>stock:</div>
                    <div className='datUse'>Ventas</div>
                    <div className='datUse'>Ultimo Surtido:</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>
                <div className='productlDB'>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id:</div>
                    <div className='datUse'>Costo</div>
                    <div className='datUse'>stock:</div>
                    <div className='datUse'>Ventas</div>
                    <div className='datUse'>Ultimo Surtido:</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>
                <div className='productlDB'>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id:</div>
                    <div className='datUse'>Costo</div>
                    <div className='datUse'>stock:</div>
                    <div className='datUse'>Ventas</div>
                    <div className='datUse'>Ultimo Surtido:</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>
                <div className='productlDB'>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id:</div>
                    <div className='datUse'>Costo</div>
                    <div className='datUse'>stock:</div>
                    <div className='datUse'>Ventas</div>
                    <div className='datUse'>Ultimo Surtido:</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>



              </div>

            </div>
            
          </div>
      </div>
    )
  }
}
