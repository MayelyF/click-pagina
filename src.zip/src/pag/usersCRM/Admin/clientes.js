import React, { Component } from 'react'
import { useState, useEffect } from 'react'
import Adminview from './adminview'
import Nmenu from './nmenudesign'


export default ()=>
<provContex>
  <App></App>
</provContex>;

const App = () => {

return (
  <div className='home_content'>
    <div className='bgar'>
      <Nmenu/>

            <div className='content1'>
                <span>Clientes</span>
            </div>

            <div className='content'>
              <div className='Nombre'>     
                <form id="formulario" method="POST" >
                  <input name ="user"  type="text" className="input-sub" placeholder="Cliente" id="UserLogin" />
                  <button type="submit" className="btbuscador" id="btnLogin">Buscar</button>
                  <ul className="error" id="error" ></ul>
                </form>
              </div>

              <div className='dashboard3'>
                <div className='titulosDB'>
                  <div>Cliente</div>
                  <div>ID Certificado</div>
                  <div>Tipo</div>
                </div>
                <div className='contentDB'>
                  <div>Cliente</div>
                  <div>ID Certificado</div>
                  <div>Tipo</div>
                </div>
                <div className='contentDB'>
                  <div>Cliente</div>
                  <div>ID Certificado</div>
                  <div>Tipo</div>
                </div>
                <div className='contentDB'>
                  <div>Cliente</div>
                  <div>ID Certificado</div>
                  <div>Tipo</div>
                </div>
                <div className='contentDB'>
                  <div>Cliente</div>
                  <div>ID Certificado</div>
                  <div>Tipo</div>
                </div>
                <div className='contentDB'>
                  <div>Cliente</div>
                  <div>ID Certificado</div>
                  <div>Tipo</div>
                </div>
              </div>
            </div>
    </div>
  </div>
)
}

