import React, { Component } from 'react'
import Adminview from './adminview'
import Nmenu from './nmenudesign'

export default class choferes extends Component {
  render() {
    return (
      <div className='home_content'>
        <div className='bgar'>
        <Nmenu/>

            <div className='content1'>
                <span>Choferes</span>
            </div>

            <div className='content'>
                <div className='Nombre'>     
                    <select>
                        <option selected disabled>Escoge un chofer</option>
                        <option>sdfaslñdada</option>
                        <option>sdfaslñdada</option>
                        <option>sdfaslñdada</option>
                    </select>
                </div>
                <div className='semanas'>Semana 1</div>
                <div className='dashboard2'></div>
                <div className='semanas'>Semana 2</div>
                <div className='dashboard2'></div>

            </div>
        </div>
      </div>
    )
  }
}
