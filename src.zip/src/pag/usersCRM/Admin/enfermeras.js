import React, { Component } from 'react'
import Adminview from './adminview'
import Nmenu from './nmenudesign'

export default class enfermeras extends Component {
  render() {
    return (
      <div className='home_content'>
      <Nmenu/>

            <div className='content1'>
                <span>Enfermeras</span>
            </div>

            <div className='content'>
                <div className='Nombre'>     
                    <select>
                        <option selected disabled>Escoge un enfermero</option>
                        <option>Enfermero1</option>
                        <option>Enfermero2</option>
                        <option>Enfermero3</option>
                    </select>
                </div>
                <div className='semanas'>Semana 1</div>
                <div className='dashboard2'></div>

            </div>

            <div className='content'>
                <div className='dashboard2'></div>
                <div className='dashboard2'></div>
                <div className='dashboard2'></div>
                <div className='dashboard2'></div>
            </div>
        </div>

    )
  }
}
