import React, { Component } from 'react'
import Adminview from './adminview'
import Nmenu from './nmenudesign'

export default class Graficas extends Component {
  render() {
    return (
    <div className='home_content'>
      <div className='bgar'>
      <Nmenu/>

        <div className='content1'>
            <span>Graficas</span>
        </div>

        <div className='content'>
          <div className='dashboard1'></div>
          <div className='dashboard1'></div>
          <div className='dashboard1'></div>


        </div>
      </div>
    </div>
    )
  }
}
