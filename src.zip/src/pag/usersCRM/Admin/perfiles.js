import React, { Component } from 'react'
import Nmenudesign from './nmenudesign'

export default class perfiles extends Component {
  render() {
    return (
      <div className='home_content'>
          <Nmenudesign/>
          <div>
            <div className='content1'>
                <span>Perfil Manager</span>
            </div>

            <div className='content'>
              <div className='Nombre'>     
                <form id="formulario" method="POST" >
                  <input name ="user"  type="text" className="input-sub" placeholder="Perfil" id="UserLogin" />
                  <button type="submit" className="btbuscador" id="btnLogin">Buscar</button>
                  <ul className="error" id="error" ></ul>
                </form>
              </div>
              <div className='bCon'><a href='/NuevoPerfil'>Crear nuevo perfil</a></div>
              <div className='dashboard6'>
                <div className='profDB'>
                  Perfiles
                </div>

                <div className='perfilDB'>
                    <i class='bx bx-user-circle'></i>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id perfil:</div>
                    <div className='datUse'>celular</div>
                    <div className='datUse'>E-mail:</div>
                    <div className='datUse'>CP</div>
                    <div className='datUse'>Direccion</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>

                <div className='perfilDB'>
                    <i class='bx bx-user-circle'></i>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id perfil:</div>
                    <div className='datUse'>celular</div>
                    <div className='datUse'>E-mail:</div>
                    <div className='datUse'>CP</div>
                    <div className='datUse'>Direccion</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>

                <div className='perfilDB'>
                    <i class='bx bx-user-circle'></i>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id perfil:</div>
                    <div className='datUse'>celular</div>
                    <div className='datUse'>E-mail:</div>
                    <div className='datUse'>CP</div>
                    <div className='datUse'>Direccion</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>

                <div className='perfilDB'>
                    <i class='bx bx-user-circle'></i>
                    <div className='datUse'>nombre:</div>
                    <div className='datUse'>id perfil:</div>
                    <div className='datUse'>celular</div>
                    <div className='datUse'>E-mail:</div>
                    <div className='datUse'>CP</div>
                    <div className='datUse'>Direccion</div>
                    <div className='DIVCont'>
                      <div className='btICont'><i class='bx bx-user-x'></i></div>
                      <div className='btICont'><i class='bx bxs-edit-alt'></i></div>
                    </div>
                </div>

              </div>

            </div>
            
          </div>

      </div>
    )
  }
}
