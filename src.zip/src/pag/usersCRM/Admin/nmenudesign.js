import { useState } from 'react'
import React from 'react'

export default function useNmenudesign() {
    const [Sidebar, setSidebar] = useState(false)

    const ShowSidebars = () => setSidebar(!Sidebar)
     return (
          <div>
              <div class={ Sidebar ? 'sidebar active'  : 'sidebar' }>
                  <div className='logsidebar'>
                      <div className='logCont'>
                          <i class='bx bxl-c-plus-plus'></i>
                          <div className='logTxt'>Clicklab</div>
                      </div>
                      <i class='bx bx-menu' id='btn' onClick={ShowSidebars}></i>
                  </div>
                  <ul className='nav_list'>
                      <li>
                          <a href='/admin'>
                              <i class='bx bxs-home-alt-2'></i>
                              <span className='links_name'>Dashboard</span>
                          </a>
                          <span className='tool'>Dashboard</span>
                      </li>
                      <li>
                          <a href='/poreditar1'>
                              <i class='bx bx-signal-3'></i>
                              <span className='links_name'>Graficas</span>
                          </a>
                          <span className='tool'>Graficas</span>
                      </li>
                      <li>
                          <a href='/poreditar2'>
                              <i class='bx bx-street-view'></i>
                              <span className='links_name'>Enfermeras</span>
                          </a>
                          <span className='tool'>Enfermeras</span>
                      </li>
                      <li>
                          <a href='/poreditar3'>
                              <i class='bx bx-car'></i>
                              <span className='links_name'>Choferes</span>
                          </a>
                          <span className='tool'>Choferes</span>
                      </li>
                      <li>
                          <a href='/poreditar4'>
                              <i class='bx bxs-home-alt-2'></i>
                              <span className='links_name'>Productos</span>
                          </a>
                          <span className='tool'>Productos</span>
                      </li>
                      <li>
                          <a href='/poreditar5'>
                              <i class='bx bxs-home-alt-2'></i>
                              <span className='links_name'>Perfiles</span>
                          </a>
                          <span className='tool'>Perfiles</span>
                      </li>
                      <li>
                          <a href='/poreditar6'>
                              <i class='bx bxs-user-detail'></i>
                              <span className='links_name'>Clientes</span>
                          </a>
                          <span className='tool'>Clientes</span>
                      </li>
                      <li>
                          <a href='/poreditar7'>
                              <i class='bx bx-notepad'></i>
                              <span className='links_name'>Certificados</span>
                          </a>
                          <span className='tool'>Certificados</span>
                      </li>
    
                  </ul>
                  <div className='profile_content'>
                      <div className='profileSide'>
                          <div className='profile_details'>
                              <img src='/img/profile.jpg' alt='' className='' />
                              <div className='name_job'>
                                  <div className='name'>Daniel</div>
                                  <div className='job'>sdadasa</div>
                              </div>
                          </div>
                          <i class='bx bx-log-in' id='log_out'></i>
                      </div>
                  </div>
              </div>

          </div>
    )
}

