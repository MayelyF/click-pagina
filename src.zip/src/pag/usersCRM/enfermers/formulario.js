import React from 'react'

export default function Formulario({data, setData}) {
  return (
    <div>
        <div className="img">
                  <img src='#' alt="Pruebas"></img>
                </div>
                <div className='form10'>
                    <div className='contemail'>
                    <p className='email'>Introduzca su Email<span className='obliga'> * </span></p>
                    <input name="email" value={data.email} onChange={(e)=>
                    setData({...data, email: e.target.value})} className='inpemail' required type="email" placeholder='Email'></input><br/>
                    </div>

                    <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                    <p><span>Nombre del Flebotomista</span><span className='obliga'> * </span></p>
                    <br />
                    <select className='select'  name="flebotomista" value={data.flebotomista} onChange={(e) => {
                        setData({...data, flebotomista: e.target.value})
                    }} required>
                        <option value="0">Elige</option>
                        <option value="Sam">Sam</option>
                        <option value="Diana">Diana</option>
                        <option value="Cecilia">Cecilia</option>
                        <option value="Mariana">Mariana</option>
                        <option value="Itzel">Itzel</option>
                        <option value="Jacquie">Jacquie</option>
                        <option value="Miguel">Miguel</option>
                        <option value="Brandon moto">Brandon moto</option>
                        <option value="Santillan">Santillan</option>
                        <option value="Viri">Viri</option>
                        <option value="Irving">Irving</option>
                        <option value="Ericka">Ericka</option>
                        <option value="Jessica">Jessica</option>
                        <option value="Nemiliz CDMX">Nemiliz CDMX</option>
                        <option value="Nemiliz Qro">Nemiliz Qro</option>
                        <option value="Danthe Qro">Danthe Qro</option>
                    </select><br/>
                </div>
    </div>
  )
}
