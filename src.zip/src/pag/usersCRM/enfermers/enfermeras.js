import React, { Component } from 'react'
import Nmenu from '../enfermers/nmenudesign'

export default class enfermeras extends Component {
  render() {
    return (
      <div className='home_content'>
      <Nmenu/>

            <div className='content1'>
                <span>Enfermeras</span>
            </div>

            <div className='content'>
                <div className='Nombre'>     
                    <span>Nombre1</span>
                </div>
                <div className='semanas'>Semana 1</div>
                <div className='dashboard2'></div>

            </div>

            <div className='content'>
                <div className='dashboard2'></div>
                <div className='dashboard2'></div>
                <div className='dashboard2'></div>
                <div className='dashboard2'></div>
            </div>
        </div>

    )
  }
}
