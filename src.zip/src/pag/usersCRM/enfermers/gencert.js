import jsPDF from 'jspdf';
import React, { Component } from 'react'

export default class pruebas extends Component {
  render() {
    const generatePDF=(e)=>{
      e.preventDefault();
      let paciente = "NameDefault";
      let doc = new jsPDF("p","pt","A4");
      doc.html(document.querySelector("#contentpdf1"),{
          callback: function(pdf){
            let pageCount = doc.internal.getNumberOfPages();
            pdf.deletePage(pageCount);
            pdf.save(`Certificado ${paciente}`);
          }
        }      
      )
    }

    return (
      <div className='cert_cont'>
        <div id='contentpdf1'>
          <div className='logcer'>
            <img src="/img/CLAB LOGO IMAGEN FONDO BLANCO TRANSPARENTE.png" className='imglocer'/>
          </div>
          <div className='topcer'>
            <div className='topizq'>
              <p>Paciente:</p>
              <p>Fecha de nacimiento:</p>
              <p>Edad:</p>
              <p>Pasaporte:</p>
            </div>
            <div className='topder'>
              <p>Fecha:</p>
              <p>Fecha toma:</p>
              <p>Hora toma:</p>
            </div>
          </div>
          <div className='tabcer'>
            <div className='toptabcer'>
              <div>Estudio</div>
              <div>Resultado</div>
              <div>Unidad</div>
              <div>Valor de referencia</div>
            </div>
            <div className='toptabcer2'>
              <div>SARS COV19</div>
              <div>Neg</div>
              <div>1</div>
              <div>Neg</div>
            </div>
            <div className='metodo'>
              Metodo:
            </div>
          </div>
          <div className='footcer'>
            <div className='topizq2'>
                <p>
                  Mediante aplicación de prueba Abbott Panbio prueba de hisopado nasofaríngeo, 
                  por antígenos SARS-C0V2: Producto para uso de profesional médico. (T) line 
                  muestra los anticuerpos inmovilizados en las líneas de prueba para formar una
                  línea sólida visible o una línea rosa tenue para indicar resultados positivos. Sino 
                  existe evidencia en lamuestra del SARS-C0V2, no aparecerá una línearosa en la
                  línea. (C) linea positiva indica la aplicación correcta de la prueba.
                </p>
                <p>
                  AutorizaciónCofepris:212201536X1062<br/>
                  ValidaciónINDRE:OficioDGE-DSAT-14935-2020
                </p>
                <p>
                  Bajío2342BcolromaSurCDMXCP.06760Cuauhtemoc<br/>
                  Tel:(55)89410999-(55)89410004
                </p>
              </div>
              <div className='topder2'>
                <img src="/img/QR.jpeg" className='imglocer2'/>
              </div>
          </div>
        </div>
        <div className='brArt'></div>
        <button id='botoncertificado' onClick={generatePDF}>Inicia sesion</button>
      </div>
    )
  }
}
