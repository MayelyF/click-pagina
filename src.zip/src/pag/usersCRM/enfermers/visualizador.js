/* import React, { Component } from 'react'
import { ReactDOM } from 'react'
//import { PDFViewer } from '@react-pdf/renderer'


export default class visualizador extends Component {
  render() {
    return (
      <div>

      </div>
    )
  }
}
 */