import React from 'react'

export default function Formulario3({data, setData}) {
  return (
    <div>
        <form  className='form10'>
            <div className='seccion'>
                <p>Registro de Prueba</p>
            </div>
            <p><span>Tipo de Prueba Realizada</span><span className='obliga'> * </span></p>
            <select name="prueba" value={data.prueba} onChange={(e)=>{
                setData({...data, prueba: e.target.value})
            }} required>
                <option value="0">Elige</option>
                <option value="PCR-RT SARS-COV-2">PCR-RT SARS-COV-2</option>
                <option value="PCR e Influenza">PCR e Influenza</option>
                <option value="Antígenos SARS-COV-2">Antígenos SARS-COV-2</option>
                <option value="Anticuerpos Cualitativos">Anticuerpos Cualitativos</option>
                <option value="Anticuerpos Cuantitativos">Anticuerpos Cuantitativos</option>
                <option value="QS">QS</option>
                <option value="BH">BH</option>
                <option value="Check UP">Check UP</option>
                <option value="">Otro</option>
            </select>
                <input type="text" name="prueba" value={data.prueba} onChange={(e)=>{
                    setData({...data, prueba: e.target.value})
                }} placeholder="Otro"></input>

            <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

            <p><span>Fecha de Toma</span><span className='obliga'> * </span></p>
            <input type="date" name='fechaToma' value={data.fechaToma} onChange={(e)=>{
                    setData({...data, fechaToma: e.target.value})
                }} required></input>

            <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

            <p><span>Hora de Toma (Formato 24 Horas)</span><span className='obliga'> * </span></p><br/>
            <p className='aclaracion'>Escribe la hora en la que hiciste la toma, por ejemplo: 18:00 hrs y NO escribas 6pm</p>
            <input type="text" name="horaToma" value={data.horaToma}  onChange={(e)=>{
                    setData({...data, horaToma: e.target.value})
                }} placeholder="Tu respuesta" required></input>

            <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

            <p><span>¿Mostró comprobante de pago?</span><span className='obliga'> * </span></p>
            <select name="comprobantePago" value={data.comprobantePago} onChange={(e)=>{
                setData({...data, comprobantePago: e.target.value})
            }} required>
                <option value="1">Sí</option>
                <option value="0">No</option>
            </select>

            <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>Monto Pagado</span><span className='obliga'> * </span></p><br/>
                <p className='aclaracion'>Escribe el monto que viste en el comprobante que te mostró. <br/>
                    En caso de que NO te hayan mostrado comprobante escribe No mostró cmprobante, o escribe cero.</p>
                <input type="text" name="monto" value={data.monto} onChange={(e)=>{
                setData({...data, monto: e.target.value})
            }} placeholder="Tu respuesta" required></input>

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>Forma de pago</span></p>
                <select name="formaPago" value={data.formaPago} onChange={(e)=>{
                setData({...data, formaPago: e.target.value})
            }} required>
                        <option value="0" selected>Elige</option>
                        <option value="Transferencia" selected>Transferencia</option>
                        <option value="Clip">Clip</option>
                        <option value="Paypal">Paypal</option>
                        <option value="Efectivo">Efectivo</option>
                        <option value="Convenio">Convenio</option>
                        <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
                </select>

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>Pago (Ingresa los números de folio de transferencia)</span><span className='obliga'> * </span></p><br/>
                <p className='aclaracion'>Esta información la encuentras en el comprobante, escribe los últimos dígitos del folio</p>
                <input type="text" name="digitosPago" value={data.digitosPago} onChange={(e)=>{
                setData({...data, digitosPago: e.target.value})
            }} placeholder="Tu respuesta" required></input>

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>Resultado</span><span className='obliga'> * </span></p>
                <div className="resultado">
                <select name="resultado" value={data.resultado} onChange={(e)=>{
                setData({...data, resultado: e.target.value})
            }} required>
                        <option value="">Elige</option>
                        <option value="Positivo">Positivo</option>
                        <option value="Negativo">Negativo</option>
                        <option value="En proceso">En proceso (En caso de PCR y otros estudios)</option>
                    </select><br/>
                </div><br />

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>Tipo de Cliente</span><span className='obliga'> * </span></p>
                <select name="tipoCliente" value={data.tipoCliente} onChange={(e)=>{
                setData({...data, tipoCliente: e.target.value})
            }} required>
                        <option value="HealthLand - Serv a Domicilio" selected>HealthLand - Serv a Domicilio</option>
                        <option value="CLick Lab - Serv a Domicilio">CLick Lab - Serv a Domicilio</option>
                        <option value="">Otro</option>
                </select>
                        <input type="text" name="tipoCliente" value={data.tipoCliente} onChange={(e)=>{
                setData({...data, tipoCliente: e.target.value})
            }} placeholder="Otro"></input>

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>En caso de ser Convenio elige el convenio correspondiente:</span><span className='obliga'> * </span></p>
                <select name="convenio" value={data.convenio} onChange={(e)=>{
                setData({...data, convenio: e.target.value})
            }} required>
                        <option value="No Aplica" selected>No Aplica</option>
                        <option value="Carters">Carters</option>
                        <option value="Casa Retro">Casa Retro</option>
                        <option value="Conekta">Conekta</option>
                        <option value="Disney">Disney</option>
                        <option value="Dr Luciano">Dr Luciano</option>
                        <option value="Ed Forwarding">Ed Forwarding</option>
                        <option value="El Galan">El Galan</option>
                        <option value="Estadística Aplicada">Estadística Aplicada</option>
                        <option value="Fintual">Fintual</option>
                        <option value="Greystar">Greystar</option>
                        <option value="Horario Estelear">Horario Estelear</option>
                        <option value="Inmobiliria Pousin">Inmobiliria Pousin</option>
                        <option value="Juan Carols Cordero">Juan Carols Cordero</option>
                        <option value="Linces">Linces</option>
                        <option value="Mabel">Mabel</option>
                        <option value="Makken">Makken</option>
                        <option value="Off Road">Off Road</option>
                        <option value="Palmtree">Palmtree</option>
                        <option value="Partitura Secreta">Partitura Secreta</option>
                        <option value="Pruebas.com">Pruebas.com</option>
                        <option value="Rinol">Rinol</option>
                        <option value="Roomie">Roomie</option>
                        <option value="Saic Motor">Saic Motor</option>
                        <option value="Santillan">Santillan</option>
                        <option value="Se Gara">Se Gara</option>
                        <option value="TDA">TDA</option>
                        <option value="Telemexico">Telemexico</option>
                        <option value="Tous">Tous</option>
                        <option value="Upfront">Upfront</option>
                        <option value="Videocine">Videocine</option>
                        <option value="Vivaanuncios">Vivaanuncios</option>
                        <option value="5 tangos">5 tangos</option>
                        <option value="">Otros</option>
                    </select><br/>
                    <input type="text" name="convenio" value={data.convenio} onChange={(e)=>{
                setData({...data, convenio: e.target.value})
            }} placeholder='Otro Convenio'></input>

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

            <p><span>Número de WA para el envío de su certificado</span><span className='obliga'> * </span></p><br/>
                <p className='aclaracion'>Porfavor verifica con tu paciente el número de teléfono para que no haya ningún error.</p>
                <input type="number" name="numWa" value={data.numWa} onChange={(e)=>{
                setData({...data, numWa: e.target.value})
            }} placeholder="Tu respuesta" required></input>
          </form>
    </div>
  )
}
