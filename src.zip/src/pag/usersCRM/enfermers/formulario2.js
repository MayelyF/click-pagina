import React from 'react'
import { useState } from 'react'

export default function Formulario2({data, setData}) {
  const [user, setUser] = useState('')
  const [password, setPassword] = useState('')
  const [Year, setYear] = useState('')

  const handleInputChange = ({target}) => {
    setUser(target.value)
  }

  const handlePassword = ({target}) => {
    setPassword(target.value)
  }
  const handleYear = ({target}) =>{
    setYear(target.value)
  }


  const handleSubmit = (e) => {
    e.preventDefault()
    const hoy = new Date();
    const dia = hoy.getDate();
    const año = hoy.getFullYear();
    const mes = (hoy.getMonth()+1);
    const converYr = parseInt(Year.substring(0,4));
    const converMh = parseInt(Year.substring(5,7));
    const converDy = parseInt(Year.substring(8,10));

    if( mes<converMh || mes==converMh){
      console.log(converMh-mes);
    }

    console.log(hoy);
    console.log(converYr, converMh, converDy, Year)
  }


  return (
    <div>
      <div className='form10'>
            <div>
                <div className='seccion'>
                    <p>Datos del Paciente</p>
                </div>
                <p><span>Nombre Completo del Paciente</span><span class='obliga'> * </span></p><br />
                <p className='aclaracion'>Escriba TODO en mayúsculas NOMBRE 1 + NOMBRE 2 + APELLIDO MATERNO + APELLIDO PATERNO. <br/>
                Escriba el nombre completo conforme al documento oficial.</p>
                <input type="text" name="paciente" value={data.paciente} onChange={(e) => {
                  setData({...data, paciente: e.target.value})
                }} required placeholder="Tu respuesta"></input><br />

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}





                <p><span>Edad</span><span className='obliga'> * </span></p>  {/*NO TIENE <br/> */}
                <input type="number" name="edad" value={data.edad} onChange={(e) => {
                  setData({...data, edad: e.target.value})
                }} required placeholder="Tu respuesta"></input><br />

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}






                <p><span>Fecha de Nacimiento</span><span className='obliga'> * </span></p><br />
                <p className='aclaracion'>Escriba DD/MM/AAAA Ej. 24/01/2022</p>
                <form id="formulario" method="POST" onSubmit={handleSubmit}>
                  <input name ="user" value={user} type="text" className="input-sub" placeholder="Usuario" id="UserLogin" onChange={handleInputChange}/>
                  <br/>
                  <br/>
                  <input name="pwd" value={password} type="text" className="input-sub" placeholder="Contraseña" id="LoginPasword" onChange={handlePassword}/>
                  <br/>
                  <input value={Year} onChange={handleYear} type='date' placeholder='año'/>
                  <button type="submit" className="btn_add_cart" id="btnLogin">Log in</button>
                  <div><br/><br/>
                  <br/></div>
                </form>







                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <div className="genero">
                    <p><span>Género</span><span className='obliga'> * </span></p>
                    <select name="genero" value={data.genero} onChange={(e) => {
                  setData({...data, genero: e.target.value})
                }} required>
                        <option value="">Elige</option>
                        <option value="Hombre">Hombre</option>
                        <option value="Mujer">Mujer</option>
                    </select><br/>
                </div>

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <div className="antigeno">
                    <p><span>En caso de ser antígeno, Requiere Certificado?</span><span className='obliga'> * </span></p>
                    <select name="antigeno" value={data.antigeno} onChange={(e) => {
                  setData({...data, antigeno: e.target.value})
                }} required>
                        <option value="">Elige</option>
                        <option value="1">Sí</option>
                        <option value="0">No</option>
                    </select><br/>
                </div><br />

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>Número de Pasaporte</span><span className='obliga'> * </span></p><br />
                <p className='aclaracion'>En caso de NO requerir certificado para viaje, escribir NO APLICA</p>
                <input type="text" name="pasaporte" value={data.pasaporte} onChange={(e) => {
                  setData({...data, pasaporte: e.target.value})
                }} required placeholder="Tu respuesta"></input><br />

                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p><span>Observaciones</span></p><br />
                <p className='aclaracion' >Escribe cualquier nota adicional que te haya dado el paciente, por ejemplo si requiere
                    resutados urgentes antes de alguna hora. Recuerda NO comprometer ningùn horario.</p>
                <textarea name="observaciones" value={data.observaciones} onChange={(e) => {
                  setData({...data, observaciones: e.target.value})
                }} placeholder="Tu respuesta"></textarea><br />
            </div>
          </div>
    </div>
  )
}
