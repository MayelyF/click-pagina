import React, { Component } from 'react'
import axios from 'axios'
import Cookies from 'universal-cookie'
const db = require('./dbData');
const cookies = new Cookies();
const config = {
  user: db.user,
  password: db.password,
  server: db.server, 
  database: db.database,
  pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
  },
  options: {
      encrypt: false, // for azure
      trustServerCertificate: false // change to true for local dev / self-signed certs
  }
};
export default function pruebas()  {

  async function getUser() {
    try {
      let response = await axios.get('https://rickandmortyapi.com/api/character');
      let {data: {results}} = response;
      let characters = results.map((character) => {return character.id})
      console.log(characters)

    } catch (error) {
      console.error(error);
    }
  }



    return (
      <div>
        <button onClick={getUser}>conseguir</button>
        <div>
          {

          }
        </div>
      </div>
    )

}
