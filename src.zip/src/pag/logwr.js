import React from 'react'
import { useState } from 'react'

const App = () => {
  const [user, setUser] = useState('')
  const [password, setPassword] = useState('')

const handleInputChange = ({target}) => {
  setUser(target.value)
}

const handlePassword = ({target}) => {
  setPassword(target.value)
}

const handleSubmit = (e) => {
  e.preventDefault()

  let account = { user, password}
  console.log(account);
  switch(password){
    case 'administrador':
      window.location = '/admin';
    break;
    case 'enfermero':
      window.location = '/Profile_Enfermero';
    break;
    case 'chofer':
      window.location = '/Profile_chofer';
    break;
    case 'administrador':
      window.location = '/admin';
    break;

    default: 
    window.location = '/loginr';
  }
}
return (
  <div>
            <br/><br/>
    <br/>
    <div className="formularioLogin">
    <div className="centerScreen"><h2>Log in</h2></div>
    <br/>
    <div className="inline">
      <form id="formulario" method="POST" onSubmit={handleSubmit}>
        <input name ="user" value={user} type="text" className="input-sub" placeholder="Usuario" id="UserLogin" onChange={handleInputChange}/>
        <br/>
        <br/>
        <input name="pwd" value={password} type="password" className="input-sub" placeholder="Contraseña" id="LoginPasword" onChange={handlePassword}/>
        <br/>
        <button type="submit" className="btn_add_cart" id="btnLogin">Log in</button>
        <div><br/><br/>
        <div className='centerScreen'><div className='redtxt'>Contraseña incorrecta vuelve a intentarlo</div></div>
        <br/></div>
      </form>
    </div>
    </div>
  </div>
)
}

export default App;
