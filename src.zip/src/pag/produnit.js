import React from 'react'

export default function Produnit({personaje}) {

  return (
    <div class="productcontainer2">
    <div class="producto">
      <div class=" img_container">
        <div class="img2"><img src={personaje.image} className='imgProd'></img></div>
        </div>

        <div class="text-mor">
          <a href="#" class="text-mor">{personaje.name}</a>
        </div>

        <div class="text-mor">
          <div class="line">____________</div>          
          {personaje.status} <br/>
          {personaje.species}
          </div>
          <div class="btn-right"><button class="btn_add_cart">Agregar Al Carrito</button></div>
      </div>
    </div>
  )
}
