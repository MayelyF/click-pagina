import axios from 'axios'
import React, { useState } from 'react'
import Cookies from 'universal-cookie'

const App = () => {
  
  const [UserName, setUserName] = useState('')
  const [Password, setPassword] = useState('')
  const [user, setUser] = useState()
  const [wrongPasword, setWrongPasword] = useState(true)
  const [Cart, setCart] = useState([1,2,3])
  const cookies = new Cookies();
  cookies.set('cart', Cart, {path:'/'});
  /*const inputChange = ({ target }) => {
    //name y value del input, target vendria siendo el input
    const { name, value } = target
    setData({
        ...data,
        [name]: value
    })
}*/
const handleChange1 = ({target})=>{
  setUserName(target.value)
}
const handleChange2 = ({target})=>{
  setPassword(target.value)
}


const send=()=>{
    axios.post(  'http://localhost:3001/register4', 
    {
      UserName:UserName,
      Password:Password
    
    })
    .then(res => {
        console.log(res.data)
        const usuario = res.data;
        if(usuario.ClientePassword===Password){
          window.location.replace('/')
        }
        else{
          setWrongPasword(false)
        }
    }).catch(error=>{
        alert('Error al actualizar')
        console.log(error);
    })
}
const value = '123'
const masc = value.toUpperCase

      /*axios.post('http://localhost:4000/api/login', body)
      .then(({ data }) => {
        console.log(data);
        if(data == "login"){
          console.log(data);
          window.location = "/admin"
        }else{
          console.log(data);
        }
      

    })
    .catch(({ response }) => {
        console.log(response.data)
    })*/
  
    const regresar=()=>{
      window.location.replace("/");
    }

    const enviar = ()=>{
      console.log('hola')
    }


  return (
    <div className='login123'> 
      <img src='/img/5.png' className='imgBlur'/>
      <div className='blur'></div>
      <div className="centerScreen">

        <div className="inline" >
          <form className='Login' id='contentpdf'>
            <div >
              <p className='bajar'>Log In</p>
              <div>
                <p className='p'>Usuario:</p>
                <input className="input-sub4" type ="text" name ="UserName" placeholder="Enter First Name" value={UserName} 
                onChange={handleChange1} />
              </div>
              <div>
                <p className='p'>Contraseña:</p>
                <input className="input-sub4" type ="password" name = "UserPassword" placeholder="Enter Last Name" 
                value={Password} onChange={handleChange2}/>
              </div>
              {
                wrongPasword ? <div></div>:<div className='WrongPass'>Contraseña o usuario equivocados</div>
              }


              <div className='flexxor'>
                <div className="btn_add_cart7" onClick={send}><p>Iniciar sesion</p></div>
                <a>¿olvidaste tu contraseña?</a>
              </div>
            </div>

          </form>
          
        </div>
      </div>
  </div>
  )
}

export default App;
