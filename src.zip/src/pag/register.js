import axios, { Axios } from 'axios'
import React, { Component, useState } from 'react'


export default function Register () {


    const [Input1, setInput1] = useState('')
    const [Input2, setInput2] = useState('')
    const [Input3, setInput3] = useState('')
    const [Input4, setInput4] = useState('')
    const [Input5, setInput5] = useState('')
    const [Input6, setInput6] = useState('')
    const [Input7, setInput7] = useState('')
    const [Input8, setInput8] = useState('')
    const [Input9, setInput9] = useState('')
    const [Input10, setInput10] = useState('')
    const [Input11, setInput11] = useState('')

    let edad;
    let edad2;

    const handleinput1=({target})=>{
      setInput1(target.value.toUpperCase())
    }
    const handleinput2=({target})=>{
      setInput2(target.value.toUpperCase())
    }
    const handleinput3=({target})=>{
      setInput3(target.value.toUpperCase())
    }
    const handleinput4=({target})=>{
      setInput4(target.value.toUpperCase())
    }
    const handleinput5=({target})=>{
      setInput5(target.value.toUpperCase())
    }
    const handleinput6=({target})=>{
      setInput6(target.value.toUpperCase())
    }
    const handleinput7=({target})=>{
      setInput7(target.value.toUpperCase())
    }
    const handleinput8=({target})=>{
      setInput8(target.value.toUpperCase())
    }
    const handleinput9=({target})=>{
      setInput9(target.value.toUpperCase())
    }
    const handleinput10=({target})=>{
      setInput10(target.value.toUpperCase())
    }
    const handleinput11=({target})=>{
      setInput11(target.value.toUpperCase())
    }


    //Funcion fecha de hoy a tipo date de SQLserver
    let date = new Date()
    let day = date.getDate()
    let month = date.getMonth() + 1
    let year = date.getFullYear()
    let hoy = 1;
    if(month < 10){
      hoy=`${year}/0${month}/${day}`
    }else{
      hoy=`${year}/${month}/${day}`
    }



    //Convertir el tipo de fecha
    let fecharray = Input11.split('-');
    let fetchTypeSQL = `${fecharray[0]}/${fecharray[1]}/${fecharray[2]}`

    //Extraccion de la edad
    var hoyFuncion = new Date();
    var cumpleanos = new Date(Input11);
    edad = hoyFuncion.getFullYear() - cumpleanos.getFullYear();
    var m = hoyFuncion.getMonth() - cumpleanos.getMonth();
    edad2 = edad;
    if (m < 0 || (m === 0 && hoyFuncion.getDate() < cumpleanos.getDate())) {
        edad = edad--;
    }


  

    const send = ()=>{
      axios.post(  'http://localhost:3001/register3', 
      {
        nombre:Input1, ApPaterno:Input2, 
        ApMaterno:Input3, UserName:`User${Input1}${Input2}${fecharray[2]}`,
        Password:`${Input1}${Input2}${fecharray[0]}`, FechaLogin:'FechaDefault', 
        ClienteFechaPassword:'Default', FechaRegistro:hoy,
        Telefono:Input4,Calle:Input6, 
        Colonia:Input7, CodigoPostal:Input8,
        Correo:Input5, Edad123:edad2, FechaNacimiento:fetchTypeSQL
      
      })
      .then(res => {
          alert(res.data)
      }).catch(error=>{
          alert('Error al actualizar')
          console.log(error);
      })
    }
    const send2 = ()=>{
      console.log(Input11)

    }

    return (
      <div>
        <br/>
        <div className="centerScreen">



          <div className='registerform'>
            <div className='registertop'>Register</div>
            <div className='registerfila'>
              <div className='registertitl'>Nombre(s)</div>
              <div className='registerinp'> <input type='text' value={Input1} onChange={handleinput1} /> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Apellido Paterno</div>
              <div className='registerinp'> <input type='text' value={Input2} onChange={handleinput2} /> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Apellido Materno</div>
              <div className='registerinp'> <input type='text' value={Input3} onChange={handleinput3}/> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Telefono</div>
              <div className='registerinp'> <input type='text' value={Input4} onChange={handleinput4}/> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Correo</div>
              <div className='registerinp'> <input type='text' value={Input5} onChange={handleinput5}/> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Calle</div>
              <div className='registerinp'> <input type='text' value={Input6} onChange={handleinput6}/> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Colonia</div>
              <div className='registerinp'> <input type='text'value={Input7} onChange={handleinput7} /> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Codigo postal</div>
              <div className='registerinp'> <input type='text'value={Input8} onChange={handleinput8} /> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Municipio/Alcaldia</div>
              <div className='registerinp'> <input type='text'value={Input9} onChange={handleinput9} /> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>Estado</div>
              <div className='registerinp'> <input type='text'value={Input10} onChange={handleinput10} /> </div>
            </div>
            <div className='registerfila'>
              <div className='registertitl'>FechaNacimiento</div>
              <div className='registerinp'> <input type='date'value={Input11} onChange={handleinput11} /> </div>
            </div>
            <br/>
            <div className='registerfila2' > <button onClick={send} className='btndob2' >Registrarme</button> </div>

          </div>        
        </div>
      </div>
    )
}

