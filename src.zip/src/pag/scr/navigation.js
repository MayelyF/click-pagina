import React, { Component } from 'react'

export default class navigation extends Component {
  render() {
    return (
      <div className='navigation'>
        <div className="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container p-2" id='Navigator'>
            <img src="/img/CLAB LOGO IMAGEN FONDO BLANCO TRANSPARENTE.png" className="logo-navbar" alt="Website Logo"/>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav ml-auto">

                    <li className="dropdown">
                      <div className="userBtn">
                        <a className="dropbtn nav-link" href="/">Inicio</a>
                      </div>
                    </li>

                    <li className="dropdown">
                        <a className="dropbtn nav-link">Estudio a Domicilio</a>
                        <ul className="dropdown-content">
                            <li><a href="#" className="nav-link">Estudios de laboratorio</a></li>
                            <li><a href="#" className="nav-link">Cotiza tu Estudio</a></li>
                        </ul>
                    </li>

                    <li className="dropdown">
                        <a className="dropbtn nav-link" href="/nosotros">Nosotros</a>
                        <ul className="dropdown-content">
                            <a href="/vacantes" className="nav-link">Vacantes</a>
                            <a href="/cobertura" className="nav-link">Cobertura clicklab</a>
                            <a href="/nuestro_equipo" className="nav-link">Nuestro equipo</a>
                            <a href="#" className="nav-link">Aviso de privacidad</a>
                        </ul>
                    </li>

                    <li className="dropdown">
                        <a className="dropbtn nav-link" href="/sucursales">Sucursales</a>
                    </li>

                    <li className="dropdown">
                        <a className="dropbtn nav-link">Más</a>
                        <ul className="dropdown-content">
                            <li><a href="/contacto" className="nav-link">Contacto</a></li>
                            <li><a href="" className="nav-link">Comprar</a></li>
                            <li><a href="" className="nav-link">Pedidos</a></li>
                        </ul>
                    </li>

                    <li className="dropdown">
                        <div className="userBtn">
                            <a className="dropbtn nav-link" href="https://www.google.com.mx/maps/place/HEALTHLAND+MEXICO/@19.4004883,-99.1688951,15z/data=!4m5!3m4!1s0x85d1ffdcf56ce15d:0x835d2bffdb43be8e!8m2!3d19.4033218!4d-99.1644534" target="_blank">Ubicación</a>
                        </div>
                    </li>

                    <li className="dropdown">
                        <a className="dropbtn nav-link" href="#">55 8941 0004</a>
                    </li>
                
                    <li className="dropdown">
                        <div className="userBtn">
                            <a className="dropbtn nav-link" href="https://www.instagram.com/clicklab_mx/" target="_blank"><img src="/img/insta.png" alt="" class="insta_img"/></a>
                        </div>
                    </li>

                    <li className="dropdown">
                        <div className="userBtn">
                            <a className="dropbtn nav-link" href="/login"><i class="fa-solid fa-circle-user"></i>Log in</a>
                        </div>
                    </li>
                    <li className="dropdown">
                      <div className="userBtn">
                        <a className="dropbtn nav-link" href="/register">Register</a>
                      </div>
                    </li>

                    <li className="dropdown">
                      <div className="userBtn">
                        <a className="dropbtn nav-link" href="/cart"><i class="fas fa-shopping-bag"></i></a>
                      </div>
                    </li>


              </ul>
            </div>
          </div>
        </div>

      </div>
    )
  }
}
