import React, { Component } from 'react'

export default class Chatbutton extends Component {
  render() {
    return (
      <div>
          <button id="chat"> <i class='bx bxs-message-rounded-detail'></i> !Vamos a chatear¡</button>
      </div>
    )
  }
}
