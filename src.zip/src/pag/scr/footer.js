import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div>
            <footer className="bg-light text-center p-2">
            <p className="h8">&copy; 2021 por clicklab.</p>
            </footer>
      </div>
    )
  }
}
