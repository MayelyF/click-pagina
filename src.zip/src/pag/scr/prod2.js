import React, {useState} from 'react'

export default function useProd2() {
    const [show, setShow] = useState(false)
    return (
      <div>
          {
              show?<div>
                <div className=" img_container">
                    <div className="img3"><img src='img/im4.jpg' className='prod2img'/></div>
                    <div className="img3"><img src='img/im5.jpg' className='prod2img'/></div>
                </div>
                <div className=" img_container">
                    <div className="img3"><img src='img/im6.jpg' className='prod2img'/></div>
                    <div className="img3"><img src='img/im7.jpg' className='prod2img'/></div>
                    <div className="img3"><img src='img/im8.jpg' className='prod2img'/></div>
                </div>    
              </div>:null
          }

          <div className='centbtndob'>
            <button onClick={()=>setShow(true)} className='btndob' >Mostrar Más</button>
            <button onClick={()=>setShow(false)} className='btndob'>Mostrar Menos</button>
          </div>


          </div>
    )
}

