const db = require('./dbData');
const sql = require('mssql');
const cors = require('cors');
const express = require('express');
const app = express();
const morgan = require("morgan");

app.set('port', process.env.PORT || 5000);
app.set('json spaces', 2);

app.use(morgan('dev'));
app.use(express.urlencoded({extended:false}));
app.use(express.json());

app.get('/', (req, res)=>{
    res.json({'hello world':'hello'});
});
async function getConection(){
    try{
        const pool = await sql.connect(db);
        return pool;
    }
    catch (error){
        console.error(error);
    }

}
getConection();

app.listen(5000, () => console.log('hola soy el servidor'))