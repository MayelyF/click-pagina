import React, { Component } from 'react'

export default class Contacto extends Component {
  render() {
    return (
      <div>
        <div className="container p-5">
          <div className="row">
            <div className="col-sm-4 offset-md-4">
              <div className="card animated flipInY">
                <div className="card-header bg-dark text-white text-center">
                  <h3>Contact Me</h3>
                </div>
                <div className="card-body">
                  <form action="">
                    <div className="form-group">
                      <input className="form-control" type="text" placeholder="Email"/>
                    </div>
                    <div className="form-group">
                      <textarea className="form-control" name="" cols="30" rows="10" placeholder="Message"></textarea>
                    </div>
                    <div className="form-group">
                      <button className="btn btn-primary btn-block">
                        Save
                      </button>
                    </div>
                  </form>    
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
