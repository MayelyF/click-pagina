import img from '../img/img.jpg'
import React from 'react'
import { useState } from 'react'
import axios from 'axios'

export default function Formulario({data, setData}) {
  const[show, setShow] = useState({
    uno: false,
    dos: false
  })

  const [enfermero, setEnfermero] = useState({
    enfermeros: []
  })

axios.get('http://localhost:3001/enfermeros')
.then(res => {
    setEnfermero({enfermeros: res.data})
    // console.log(service.servicios);
})

  return (
    <div>
        <div className="img">
          <img className='imgPruebas' src={img} alt="Pruebas"></img>
        </div>
        <form className='frmReg'>
            <p className='par'><span>Introduzca Email</span><span className='obliga'> * </span></p><br/>
                <input className='email' type="email" name="email" value={data.email} onChange={(e)=>{
                setData({...data, email: e.target.value})
            }} placeholder="Tu respuesta" required></input>

        <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
        <button onClick={()=>setShow({...show, uno: true})} className='btncont' >Continuar</button>

            {show.uno?<div>
              <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
              <p className='par'><span>Sucursal</span><span className='obliga'> * </span></p>
                  <select required className='select' name="sucursal" value={data.sucursal} onChange={(e)=>{
                  setData({...data, sucursal: e.target.value})
              }}>
                <option value="">Otro</option>
                <option value="HealthLand - Serv a Domicilio">HealthLand - Serv a Domicilio</option>
                <option value="CLick Lab - Serv a Domicilio">CLick Lab - Serv a Domicilio</option>
              </select>
                <input className='inpText' type="text" name="sucursal" value={data.sucursal} onChange={(e)=>{
                    setData({...data, sucursal: e.target.value})
                }} placeholder="Otro" required></input>

        <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
        <button onClick={()=>setShow({...show, uno: false})} className='btncont' >Regresar</button>
        <button onClick={()=>setShow({...show, dos: true})} className='btncont' >Continuar</button>

        {show.dos?<div>
          <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
            <p className='par'><span>Nombre del Flebotomista</span><span className='obliga'> * </span></p>
            <br />
            <select className='select'  name="enfermero" value={data.enfermero} onChange={(e) => {
                setData({...data, enfermero: e.target.value})
            }} required>
                <option value="">Elige</option>
                {enfermero.enfermeros.map(elemento => (
                    <option key={elemento.IdEnfermero} value={elemento.IdEnfermero}>{elemento.NombreE}</option>
                ))}

            </select><br/>
          </div>:null}
          </div>:null}
        </form>
    </div>
  )
}
