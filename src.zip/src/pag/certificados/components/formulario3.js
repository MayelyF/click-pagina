import React, { useState } from 'react'
import axios from 'axios'

export default function Formulario3({data, setData}) {

    const [show, setShow] = useState({
        uno: false,
        dos: false,
        tres: false,
        cuatro: false,
        cinco: false,
        seis: false,
        siete: false,
        ocho: false
    })

    const [service, setService] = useState({
        servicios: []
    })

    axios.get('http://localhost:3001/services')
    .then(res => {
        setService({servicios: res.data})
        // console.log(service.servicios);
    })

    const [convenio, setConvenio] = useState({
        convenios: []
    })

    axios.get('http://localhost:3001/convenios')
    .then(res => {
        setConvenio({convenios: res.data})
        // console.log(service.servicios);
    })


  return (
    <div>
        <form className='frmReg'>
            <div className='seccion'>
                <p className='psec'>Registro de Prueba</p>
            </div>
            <p className='par'><span>Tipo de Prueba Realizada</span><span className='obliga'> * </span></p>
            {/* <select className='select' name="prueba" value={data.prueba} onChange={(e)=>{ */}
                {/* setData({...data, prueba: e.target.value}) */}
            {/* }} required> */}
                <option value="">Elige</option>
                <ul>
                {service.servicios.map(elemento => (
                    <option key={elemento.IdTipoPrueba} value={elemento.NombreTP}>{elemento.NombreTP}</option>
                ))}
                </ul>
            {/* </select> */}

            <input className='inpText' type="text" name="prueba" value={data.prueba} onChange={(e)=>{
                setData({...data, prueba: e.target.value})
            }} placeholder='Otro'></input>

            <div></div>

            <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
            <button onClick={()=>setShow({...show, uno: true})} className='btncont' >Continuar</button>

            {show.uno?<div>
            <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
            <p className='par'><span>Fecha de Toma y Hora de Toma</span><span className='obliga'> * </span></p>
            <div>
            <input className='inpDate' type="date" name='fechaToma' value={data.fechaToma} onChange={(e)=>{
                    setData({...data, fechaToma: e.target.value})
                }} required></input>
            <input className='inpText' type="time" min="00:00" max="23:59" name="horaToma" value={data.horaToma}  onChange={(e)=>{
                    setData({...data, horaToma: e.target.value})
                }} placeholder="Tu respuesta" required></input>
                </div>
                
                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>setShow({...show, uno: false})} className='btncont' >Regresar</button>
                <button onClick={()=>setShow({...show, dos: true})} className='btncont' >Continuar</button>
            
            {show.dos?<div>
            <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
            <p className='par'><span>¿Mostró comprobante de pago?</span><span className='obliga'> * </span></p>
            <select className='select' name="comprobantePago" value={data.comprobantePago} onChange={(e)=>{
                setData({...data, comprobantePago: e.target.value})
            }} required>
                <option value="">Elije</option>
                <option value="1">Sí</option>
                <option value="0">No</option>
            </select>

            <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
            <button onClick={()=>setShow({...show, dos: false})} className='btncont' >Regresar</button>
            <button onClick={()=>setShow({...show, tres: true})} className='btncont' >Continuar</button>

                {show.tres?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>Monto Pagado</span><span className='obliga'> * </span></p><br/>
                <p className='aclaracion'>Escribe el monto que viste en el comprobante que te mostró. <br/>
                    En caso de que NO te hayan mostrado comprobante escribe No mostró comprobante, o escribe cero.</p>
                <input className="inpText" type="text" name="monto" value={data.monto} onChange={(e)=>{
                setData({...data, monto: e.target.value})
            }} placeholder="Tu respuesta" required></input>

                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>setShow({...show, tres: false})} className='btncont' >Regresar</button>
                <button onClick={()=>setShow({...show, cuatro: true})} className='btncont' >Continuar</button>

                {show.cuatro?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>Forma de pago</span></p>
                <select className='select' name="formaPago" value={data.formaPago} onChange={(e)=>{
                setData({...data, formaPago: e.target.value})
            }}required>
                        <option value="">Elige</option>
                        <option value="Transferencia">Transferencia</option>
                        <option value="Clip">Clip</option>
                        <option value="Paypal">Paypal</option>
                        <option value="Efectivo">Efectivo</option>
                        <option value="Convenio">Convenio</option>
                        <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
                </select>
                
                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>{data.formaPago !== "Efectivo" ? setShow({...show, cuatro: false}) : setShow({...show, cinco: false})}} className='btncont' >Regresar</button>
                <button onClick={()=>{data.formaPago !== "Efectivo" ? setShow({...show, cinco: true}) : setShow({...show, seis: true})}} className='btncont' >Continuar</button>
                
                {show.cinco?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>Pago (Ingresa los números de folio de transferencia)</span><span className='obliga'> * </span></p><br/>
                <p className='aclaracion'>Esta información la encuentras en el comprobante, escribe los últimos dígitos del folio</p>
                <input className='inpText' type="text" name="digitosPago" value={data.digitosPago} onChange={(e)=>{
                    setData({...data, digitosPago: e.target.value})
            }} placeholder="Tu respuesta" required></input>  

                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=> {setShow({...show, cinco: false})}} className='btncont' >Regresar</button>
                <button onClick={()=>{setShow({...show, seis: true})}} className='btncont' >Continuar</button>
                </div>:null}

                {show.seis?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>Resultado</span><span className='obliga'> * </span></p>
                <div className="resultado">
                <select className='select' name="resultado" value={data.resultado} onChange={(e)=>{
                setData({...data, resultado: e.target.value})
            }} required>
                        <option value="">Elige</option>
                        <option value="Positivo">Positivo</option>
                        <option value="Negativo">Negativo</option>
                        <option value="En proceso">En proceso (En caso de PCR y otros estudios)</option>
                    </select><br/>
                </div><br />

                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>{ setShow({...show, seis: false})}} className='btncont' >Regresar</button>
                <button onClick={()=>{ setShow({...show, siete: true})}} className='btncont' >Continuar</button>

                {show.siete?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>En caso de ser Convenio elige el convenio correspondiente:</span><span className='obliga'> * </span></p>
            <select className='select' name="convenio" value={data.convenio} onChange={(e)=>{
                setData({...data, convenio: e.target.value})
            }} required>
                    <option value="No Aplica" selected>No Aplica</option>
                        {convenio.convenios.map(elemento => (
                    <option key={elemento.IdConvenio} value={elemento.NombreEmpresa}>{elemento.NombreEmpresa}</option>
                ))}
                    </select><br/>
                    <input className='inpText' type="text" name="convenio" value={data.convenio} onChange={(e)=>{
                setData({...data, convenio: e.target.value})
            }} placeholder='Otro Convenio' required></input>

                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>{ setShow({...show, siete: false})}} className='btncont' >Regresar</button>
                <button onClick={()=>{ setShow({...show, ocho: true})}} className='btncont' >Continuar</button>

            {show.ocho?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
            <p className='par'><span>Número de WA para el envío de su certificado</span><span className='obliga'> * </span></p><br/>
                <p className='aclaracion'>Porfavor verifica con tu paciente el número de teléfono para que no haya ningún error.</p>
                <input className='inpNum' type="number" name="numWa" value={data.numWa} onChange={(e)=>{
                setData({...data, numWa: e.target.value})
            }} placeholder="Tu respuesta" required></input>
            </div>:null}
            </div>:null}
            </div>:null}
            </div>:null}
            </div>:null}
            </div>:null}
            </div>:null}
          </form>
    </div>
  )
}
