import React from 'react'
import { useState } from 'react';

export default function Formulario2({data, setData}) {

  const[show, setShow] = useState({
    uno: false,
    dos: false,
    tres: false,
    cuatro: false,
    cinco: false
  })

    const fecha = new Date();
    const fechaActual = `${fecha.getFullYear()}-${fecha.getMonth()+1}-${fecha.getDate()}`;
    const fActSep = fechaActual.split('-');
    const fPaciente = data.fechaNacim.split('-')

    const diferencia = [fActSep[0] - fPaciente[0], fActSep[1] - fPaciente[1], fActSep[2] - fPaciente[2]]

    if(diferencia[1]<0 ){
      diferencia[0]--
    }else if (diferencia[1]===0){
      if(diferencia[2]<0){
        diferencia[0]--
      }
    }

    data.edad = diferencia[0]


  return (
    <div>
      <form className='frmReg'>
            <div>
                <div className='seccion'>
                    <p className='psec'>Datos del Paciente</p>
                </div>
                <p className='par'><span>Nombre Completo del Paciente</span><span class='obliga'> * </span></p><br />
                <p className='aclaracion'>Escriba NOMBRE 1 + NOMBRE 2 + APELLIDO MATERNO + APELLIDO PATERNO. <br/>
                Escriba el nombre completo conforme al documento oficial.</p>
                <input className='inpText' type="text" name="paciente" value={data.paciente} onChange={(e) => {
                  setData({...data, paciente: e.target.value.toUpperCase()})
                }} required placeholder="Tu respuesta"></input><br />

                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>setShow({...show, uno: true})} className='btncont' >Continuar</button>
                
                {show.uno?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>Fecha de Nacimiento</span><span className='obliga'> * </span></p><br />
                <p className='aclaracion'>Escriba DD/MM/AAAA Ej. 24/01/2022</p>
                <input className='inpDate' type="date" name="fechaNacim" value={data.fechaNacim} onChange={(e) => {
                  setData({...data, fechaNacim: e.target.value})
                }} placeholder="Tu Respuesta" required></input><br />
                
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}

                <p className='par'><span>Edad</span><span className='obliga'> * </span></p>  {/*NO TIENE <br/> */}
                <input className='inpNum' type="text" name="edad" value={data.edad} onChange={(e) => {
                  setData({...data, edad: e.target.value})
                }} required placeholder=""></input><br />

                <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>setShow({...show, dos: false})} className='btncont' >Regresar</button>
                <button onClick={()=>setShow({...show, dos: true})} className='btncont' >Continuar</button>
                
                {show.dos?<div className="genero">
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                    <p className='par'><span>Género</span><span className='obliga'> * </span></p>
                    <select className='select' name="genero" value={data.genero} onChange={(e) => {
                  setData({...data, genero: e.target.value})
                }} required>
                        <option value="">Elige</option>
                        <option value="Hombre">Hombre</option>
                        <option value="Mujer">Mujer</option>
                    </select><br/>                

                  <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                <button onClick={()=>setShow({...show, tres: false})} className='btncont' >Regresar</button>
                <button onClick={()=>setShow({...show, tres: true})} className='btncont' >Continuar</button>

                {show.tres?<div className="antigeno">
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                    <p className='par'><span>En caso de ser antígeno, Requiere Certificado?</span><span className='obliga'> * </span></p>
                    <select className='select' name="antigeno" value={data.antigeno} onChange={(e) => {
                  setData({...data, antigeno: e.target.value})
                }} required>
                        <option value="">Elige</option>
                        <option value="1">Sí</option>
                        <option value="0">No</option>
                    </select><br/>

                    <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                    <button onClick={()=>setShow({...show, cuatro: false})} className='btncont' >Regresar</button>
                    <button onClick={()=>setShow({...show, cuatro: true})} className='btncont' >Continuar</button>

                {show.cuatro?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>Número de Pasaporte</span><span className='obliga'> * </span></p><br />
                <p className='aclaracion'>En caso de NO requerir certificado para viaje, escribir NO APLICA</p>
                <input className='inpText' type="text" name="pasaporte" value={data.pasaporte} onChange={(e) => {
                  setData({...data, pasaporte: e.target.value.toUpperCase()})
                }} required placeholder="Tu respuesta"></input><br />

                  <p class="obliga">Dé click en Continuar hasta terminar esta sección</p>
                  <button onClick={()=>setShow({...show, cinco: false})} className='btncont' >Regresar</button>
                  <button onClick={()=>setShow({...show, cinco: true})} className='btncont' >Continuar</button>

                {show.cinco?<div>
                <div className='separador'></div> {/* ESTO ES UN DIV SEPARADOR */}
                <p className='par'><span>Observaciones</span></p><br />
                <p className='aclaracion' >Escribe cualquier nota adicional que te haya dado el paciente, por ejemplo si requiere
                    resutados urgentes antes de alguna hora. Recuerda NO comprometer ningún horario.</p>
                <textarea className='textarea' name="observaciones" value={data.observaciones} onChange={(e) => {
                  setData({...data, observaciones: e.target.value})
                }} placeholder="Tu respuesta" required></textarea><br />
                </div>:null}
                </div>:null}
                </div>:null}
                </div>:null}
                </div>:null}
            </div>
          </form>
    </div>
  )
}
