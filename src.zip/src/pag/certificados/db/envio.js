const db = require('./dbData');
const sql = require('mssql');
const cors = require('cors');
const express = require('express');
const { default: axios } = require('axios');
const app = express();

app.use(express.json());
app.use(cors());

//------------VALIDACION ------------------

const config = {
    user: db.user,
    password: db.password,
    server: db.server, 
    database: db.database,
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true, // for azure
        trustServerCertificate: true // change to true for local dev / self-signed certs
    }
};

app.get('/enfermeros', (req,res)=>{
    async function getEnfermero(){
        try{
            const pool = await sql.connect(config)
            const result = await pool.request().query('SELECT IdEnfermero, NombreE FROM TblEnfermeros')
            const resp = result.recordset
            res.send(resp)
    
        } catch(error) {
            console.error(error)
        }
    }

    getEnfermero()
})

app.get('/services', (req,res)=>{
    async function getService(){
        try{
            const pool = await sql.connect(config)
            const result = await pool.request().query('SELECT NombreServicio FROM CatServicios')
            const resp = result.recordset
            res.send(resp)
    
        } catch(error) {
            console.error(error)
        }
    }

    getService()
})

app.get('/convenios', (req,res)=>{
    async function getConvenio(){
        try{
            const pool = await sql.connect(config)
            const result = await pool.request().query('SELECT NombreEmpresa FROM CatConvenios')
            const resp = result.recordset
            res.send(resp)
    
        } catch(error) {
            console.error(error)
        }
    }

    getConvenio()
})

app.post('/register', (req, res) => {
    async function insert(){
        const flebotomista = req.body.flebotomista,
            paciente = req.body.paciente,
            edad = req.body.edad,
            fechaNacim =req.body.fechaNacim,
            genero= req.body.genero,
            antigeno=req.body.antigeno,
            pasaporte=req.body.pasaporte,
            observaciones=req.body.observaciones,
            prueba=req.body.prueba,
            fechaToma=req.body.fechaToma,
            horaToma=req.body.horaToma,
            comprobantePago=req.body.comprobantePago,
            monto=req.body.monto,
            formaPago=req.body.formaPago,
            digitosPago=req.body.digitosPago,
            resultado=req.body.resultado,
            tipoCliente=req.body.tipoCliente,
            convenio=req.body.convenio,
            numWa=req.body.numWa

        try{
            let pool = await sql.connect(config)
            await pool.request().input('NombreFlebotomista', sql.VarChar, `${flebotomista}`) //cada input es un campo a llenar
            .input('NombrePaciente', sql.VarChar, `${paciente}`)
            .input('Edad', sql.Int, edad)
            .input('FechaNacimiento', sql.VarChar, `${fechaNacim}`)
            .input('Genero', sql.NChar, `${genero}`)
            .input('RequiereCertificado', sql.Bit, antigeno)
            .input('NumeroPasaporte', sql.VarChar, `${pasaporte}`)
            .input('Observaciones', sql.VarChar, `${observaciones}`)
            .input('TipoPruebaRealizada', sql.VarChar, `${prueba}`)
            .input('FechaToma', sql.VarChar, `${fechaToma}`)
            .input('HoraToma', sql.VarChar, `${horaToma}`)
            .input('MostroComprobantePago', sql.Bit, comprobantePago)
            .input('MontoPagado', sql.Int, monto)
            .input('FormaPago', sql.VarChar, `${formaPago}`)
            .input('FolioTransferencia', sql.VarChar, `${digitosPago}`)
            .input('Resultado', sql.VarChar, `${resultado}`)
            .input('TipoCliente', sql.VarChar, `${tipoCliente}`)
            .input('Convenio', sql.VarChar, `${convenio}`)
            .input('NumEnvioCertificado', sql.Int, numWa)
            .query(`INSERT INTO TblCertificadoCovid (NombreFlebotomista, NombrePaciente, Edad, FechaNacimiento, Genero, RequiereCertificado, NumeroPasaporte, Observaciones, TipoPruebaRealizada, FechaToma, HoraToma, MostroComprobantePago, MontoPagado, FormaPago, FolioTransferencia, Resultado, TipoCliente, Convenio, NumEnvioCertificado) VALUES 
            (@NombreFlebotomista, @NombrePaciente, @Edad, @FechaNacimiento, @Genero, @RequiereCertificado, @NumeroPasaporte, @Observaciones, @TipoPruebaRealizada, @FechaToma, @HoraToma, @MostroComprobantePago, @MontoPagado, @FormaPago, @FolioTransferencia, @Resultado, @TipoCliente, @Convenio, @NumEnvioCertificado)`)
    
            console.log('User inserted')
            
        } catch(error) {
            console.error(error)
        }
    }

    insert()
})

//--------------------------------------------------------------------

app.post('/register2', (req, res) => {
    async function insert2(){
        const cosas = req.body.cosas
        try{
            let pool = await sql.connect(config)
            await pool.request().query(`INSERT INTO TblClientes VALUES (1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,'9999-12-31',1,1,1,1,1,1,1,1,1,1,1);`)
    
            console.log({cosas})
            
        } catch(error) {
            console.error(error)
        }
    }

    insert2()
})


app.post('/register3', (req, res) => {
    async function actualizar2() {
        const   Nombre = req.body.nombre,
                ApPaterno = req.body.ApPaterno,
                ApMaterno = req.body.ApMaterno,
                UserName = req.body.UserName,
                Password = req.body.Password,
                FechaLogin = req.body.FechaLogin,
                ClienteFechaPassword = req.body.ClienteFechaPassword,
                FechaRegistro = req.body.FechaRegistro,
                Telefono = req.body.Telefono,
                Calle = req.body.Calle,
                Colonia = req.body.Colonia,
                CodigoPostal = req.body.CodigoPostal,
                Correo = req.body.Correo,
                Edad = req.body.Edad123,
                FechaNacimiento = req.body.FechaNacimiento
        try {
            console.log(Nombre,ApPaterno,ApMaterno)
             let pool = await sql.connect(config)
           await pool.request().query(`INSERT INTO TblClientes VALUES (1,'${Nombre}','${ApPaterno}',
           '${ApMaterno}','${UserName}','${Password}',1,'${FechaLogin}',1,1,'${ClienteFechaPassword}',
           1,1,1,'${FechaRegistro}','${FechaNacimiento}',${Edad},'${Telefono}',1,'${Correo}','${Calle}','
           ${Colonia}',1,'${CodigoPostal}','UserModDefault','FechaMOdificacionDefault',1,1,1);`)
           res.send('Registro correcto!!!  tu username es: '+UserName+' Tu contraseña es: '+Password)
        } catch (error) {
            console.error(error)
            
        }
    }

    actualizar2()
})


app.get('/UsuarioLogin', (req,res)=>{
    async function getDatos2() {
        const idCert =1,
        parametro = req.body.parametro
        try {
            console.log(parametro)
            const pool = await sql.connect(config)
            //var query2 = "exec SPS_Certificados_ID @ID_CERT = '" + idCert + "'"
            //const result = await pool.request().query(query2)
            //const resp = result.recordset
            //res.send(resp)

        } catch (error) {
            console.error(error)
        }
    }

    getDatos2()
})

app.post('/register4', (req, res) => {
    async function actualizar2() {
        const   UserName = req.body.UserName,
                Password = req.body.Password 
        try {
            console.log(UserName,Password)
             let pool = await sql.connect(config)
           const query2=`SELECT * FROM TblClientes WHERE UserName = '${UserName}'`
           const result = await pool.request().query(query2)
           const resp = result.recordset;
           res.send(resp[0])
        } catch (error) {
            console.error(error)
            
        }
    }

    actualizar2()
})
app.post('/register5', (req, res) => {
    async function actualizar2() {
        const   UserName = req.body.UserName
        try {
                console.log(UserName)
                let pool = await sql.connect(config)
                const query2=`SELECT * FROM CatServicios WHERE IdServicio= ${UserName};`
                const result = await pool.request().query(query2)
                const resp = result.recordset;
                res.send(resp[0])
                console.log(resp[0])
        } catch (error) {
            console.error(error)
            
        }
    }

    actualizar2()
})

//-----------------------------------------------

app.listen(3001, () => {
    console.log('Server running on port 3001');
})
