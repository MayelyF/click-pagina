const dbData = {
    //Aquí van los datos de acceso a la BD
    server: '189.193.252.100',  //update me
    database: 'ClickLab',
    user: 'sa',
    password: 'Pr1mus9030',
    userEmail:'crmhealthland@gmail.com',
    passEmail:'pzpxkmljawtsnkcv',
    options: {
        encript: false,
        trustedConnection: true,
        enableArithAbort: true,
        trustServerCertificate: true
    },
}

module.exports = dbData
