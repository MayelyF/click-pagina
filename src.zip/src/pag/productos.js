import React, { useEffect, useState } from 'react'
import GenProduct from './genProduct'
import axios from 'axios'

export default function useProductos() {


  const [Loadin, setLoadin] = useState(true)
  const [personajes, setproductos1] = useState([])
  const [input, setInput] = useState('')

  const function123= ()=>{
    if(personajesfilter.length == 0){
      alert("No hay productos con ese nombre");
    }
  }

  useEffect(()=>{
    const fetchProductos = async ()=>{
      const res = await fetch('https://rickandmortyapi.com/api/character');
      const data = await res.json();
      setproductos1(data.results)
      setLoadin(false);
    }
  fetchProductos()
  },[])

  const handleInputChange = ({target})=>{
    setInput(target.value)
  }
  const mostrar = ()=>{
    console.log(input)
    console.log(personajesfilter)
    function123();
  }
  const personajesfilter = personajes.filter(personaje => personaje.name.toLowerCase().includes(input.toLowerCase()));

  return (
    <div>
      <div className='centrar'>
        <form >
          <input type='text' value={input} onChange={handleInputChange } placeholder='Buscar...'className='inpabcd'/>
          <button type='submit'className='btabcd'>buscar</button>
        </form>
        <br/><button onClick={mostrar}>asda</button>
      </div>

    {
      Loadin ? <div>cargando...</div> : <GenProduct personajes={personajesfilter} />
    }
    


    </div>
  )
}