const db = require('./dbData');
const sql = require('mssql');
const express = require('express');
const app = express();

//------------VALIDACION ------------------

const users ={ Name: 'jperez', Password: '1234MH' } //esto solo representa la llegada de datos

const config = {
    user: db.user,
    password: db.password,
    server: db.server, 
    database: db.database,
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true, // for azure
        trustServerCertificate: true // change to true for local dev / self-signed certs
    }
};


async function valprofile(){
    try {
        const pool = await sql.connect(config)
        const result = await pool.request().query(`SELECT * FROM TblUsuarios WHERE UserName = '${users.Name}' AND UserPassword = '${users.Password}'`)
        const res = result.recordset           
        
        if(res[0] !== undefined){
        switch(res[0].IdPerfil){
            case 1: 
                app.get('/admin', (req,res)=>{
                    res.send('<h1>Hola Administrador</h1>')
                })
                break;
            case 2: 
                app.get('/supervisor', (req,res)=>{
                    res.send('<h1>Hola Supervisor</h1>')
                })
                break;
            case 3: 
                app.get('/client', (req,res)=>{
                    res.send('<h1>Hola Cliente</h1>')
                })
                break;
            case 4: 
                app.get('/sales', (req,res)=>{
                    res.send('<h1>Hola Gestor de Ventas</h1>')
                })
                break;
            case 5: 
                app.get('/driver', (req,res)=>{
                    res.send('<h1>Hola Chofer</h1>')
                })
                break;
            case 6: 
                app.get('/nurse', (req,res)=>{
                    res.send('<h1>Hola Enfermero</h1>')
                })
                break;
            default:
                app.get('/error', (req,res)=>{
                    res.status(404).send('<h1>Perfil no existente</h1>')
                })
        }
        }else{
            app.get('/error', (req,res)=>{
                res.status(404).send('<h1>El usuario no existe en la bd</h1>')
            })
        }

    } catch(err){
        console.error(err);
    }
}

app.listen(3001, (err)=>{
    if(err) console.log('Error in server')
    console.log('Server listening on port: 3001');
    valprofile()
})
