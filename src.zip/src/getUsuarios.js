const db = require('../dbData');
const sql = require('mssql');

async function getUsuarios(){
    try{ 
        let pool = await sql.connect(db);
        let salida = await pool.request().query('SELECT * FROM TblUsuarios');
        console.log(salida.recordset);
    }catch (err){
        console.log(err);
        
    }
}
getUsuarios();

    module.exports = {
        getUsuarios: getUsuarios
    }
