import React, { Component } from 'react'
import './App.css';
import Navigation from './pag/scr/navigation';
import Chatbutton from './pag/scr/chatbutton';
import Imports from './pag/scr/imports';
import Footer from './pag/scr/footer';
import AppRouter from './pag/AppRouter';
import './main.css'
import './pag/sql'
import './pag/menu'


function App() {
  return (
      <div className="App">
        <Imports />
        <Navigation />
        
        <AppRouter/>

        <Chatbutton />
        <Footer/>
        
        
      </div>

  );
}

export default App;
